window.onload = function () {
    tabChange();
    setIframeHeight(iframe1);

}

function tabChange() {
    var h_tab = document.querySelector('.destination>.container');
    var li_item = h_tab.getElementsByTagName('li');
    var li_length =li_item.length;
    var tabContent = h_tab.children[1].getElementsByClassName('tab_content');
    var tab_menu = document.getElementsByClassName('tab_menu')[0];

    tab_menu.onclick = function (e) { 
         if (e.target.nodeName == 'LI') {
            var index=parseInt(e.target.id.slice(3));
      
            for (var j = 0; j < li_length; j++) {
                var dClass = tabContent[j].className.split(' ');
                for (var k = 0; k < dClass.length; k++) {
                    if (dClass[k] == 'hide') {
                        dClass.splice(k, 1);
                        console.log(tabContent[j].className)
                    }    tabContent[j].className += ' hide'; //所有box都隐藏 
                }
              
                tabContent[index].className = dClass.join(' '); //当前box显示
            }
        }
    }
}

function setIframeHeight(id) {

};
